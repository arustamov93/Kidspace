import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Doctor, Institution, Service, Child, Product, CartItem, ChatSession, ChatMessage } from '../types';
import { MOCK_USERS } from '../constants';

// --- Types ---
type Language = 'ru' | 'uz';

interface UIState {
  isChatOpen: boolean;
  activeModal: 'none' | 'scan' | 'bookings' | 'wallet' | 'notifications' | 'doctor_consultation' | 'add_review' | 'booking_create' | 'child_profile' | 'cart' | 'product_details' | 'chat_list' | 'chat_room' | 'payment';
  chatTriggerMsg: string;
}

interface BookingDraft {
  institution: Institution | null;
  service: Service | null;
  date: string | null;
  time: string | null;
  child: Child | null;
}

interface PaymentConfig {
  amount: number;
  title: string;
  description: string;
  type: 'Subscription' | 'Marketplace' | 'Booking' | 'Consultation';
  onSuccess: () => void;
}

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: keyof typeof translations['ru']) => string;
  
  // UI Controls
  uiState: UIState;
  selectedDoctor: Doctor | null; 
  selectedChild: Child | null;   
  selectedProduct: Product | null; 
  reviewTargetId: string | null;
  bookingDraft: BookingDraft;
  paymentConfig: PaymentConfig | null;
  
  openChat: (msg?: string) => void; // AI Chat
  closeChat: () => void;
  toggleModal: (modal: UIState['activeModal']) => void;
  closeAllModals: () => void;
  
  // Actions
  openDoctorConsultation: (doctor: Doctor) => void; 
  openChildProfile: (child: Child) => void;
  openProductDetails: (product: Product) => void;
  openReviewModal: (institutionId: string) => void;
  startBooking: (institution: Institution, service?: Service) => void;
  updateBookingDraft: (updates: Partial<BookingDraft>) => void;

  // Cart
  cartItems: CartItem[];
  addToCart: (product: Product, quantity: number, options?: Record<string, string>) => void;
  removeFromCart: (itemId: string) => void;
  updateCartQuantity: (itemId: string, delta: number) => void;
  clearCart: () => void;

  // Chats
  chatSessions: ChatSession[];
  activeChatId: string | null;
  openChatList: () => void;
  openChatWith: (type: 'support' | 'doctor' | 'institution', entity: Doctor | Institution | null) => void;
  sendMessage: (chatId: string, text: string) => void;

  // Payments
  openPayment: (config: PaymentConfig) => void;
  processPayment: (method: 'wallet' | 'click' | 'payme' | 'uzum') => Promise<{ success: boolean; message?: string }>;
}

// --- Translations ---
const translations = {
  ru: {
    home: 'Главная',
    education: 'Обучение',
    pass: 'Pass',
    health: 'Здоровье',
    profile: 'Профиль',
    searchPlaceholder: 'Поиск школ, врачей, игрушек...',
    dailyTip: 'Совет дня',
    nearYou: 'Рядом с вами',
    openMap: 'Открыть карту',
    kidsMarket: 'Детский Маркет',
    toShop: 'В магазин',
    all: 'Все',
    myWallet: 'Мой Кошелек',
    balance: 'Общий баланс',
    topUp: 'Пополнить',
    transfer: 'Перевести',
    history: 'История операций',
    notifications: 'Уведомления',
    readAll: 'Прочитать все',
    bookVisit: 'Записаться',
    book: 'Брони',
    support: 'Поддержка',
    scan: 'Сканер',
    myKids: 'Мои Дети',
    add: 'Добавить',
    favorites: 'Избранное',
    myReviews: 'Мои Отзывы',
    logout: 'Выйти',
    bannerTitle: 'Выведите семейный отдых на новый уровень!',
    bannerSub: 'Скидки на зоопарки, парки, кино и рестораны. Экономьте с Kidspace Pass!',
    joinPass: 'Купить Kidspace Pass',
    currentPlan: 'Текущий Пакет',
    active: 'Активен',
    inactive: 'Неактивен',
    remainingBalance: 'Остаток баланса',
    manageSubs: 'Управление',
    linkedChildren: 'Дети на абонементе',
    choosePackage: 'Выберите свой пакет',
    visitsCount: 'посещений',
    buyPackage: 'Купить Пакет',
    healthTitle: 'Здоровье',
    chatWithDoctor: 'Чат с Врачом',
    notificationSettings: 'Настройки Уведомлений',
    myChats: 'Мои Чаты',
    sendMessage: 'Написать сообщение'
  },
  uz: {
    home: 'Bosh sahifa',
    education: "Ta'lim",
    pass: 'Pass',
    health: 'Salomatlik',
    profile: 'Profil',
    searchPlaceholder: "Maktab, shifokor, o'yinchoq qidirish...",
    dailyTip: 'Kun maslahati',
    nearYou: 'Yaqiningizda',
    openMap: 'Xaritani ochish',
    kidsMarket: "Bolalar Do'koni",
    toShop: "Do'konga",
    all: 'Barchasi',
    myWallet: 'Mening Hamyonim',
    balance: 'Umumiy balans',
    topUp: "To'ldirish",
    transfer: "O'tkazish",
    history: 'Amaliyotlar tarixi',
    notifications: 'Bildirishnomalar',
    readAll: "O'qib chiqish",
    bookVisit: 'Yozilish',
    book: 'Band qilish',
    support: "Qo'llab-quvvatlash",
    scan: 'Skaner',
    myKids: 'Farzandlarim',
    add: "Qo'shish",
    favorites: 'Tanlanganlar',
    myReviews: 'Sharhlarim',
    logout: 'Chiqish',
    bannerTitle: 'Oilaviy dam olishni yangi darajaga olib chiqing!',
    bannerSub: "Bog'lar, hayvonot bog'lari va kinoteatrlarga chegirmalar. Kidspace Pass bilan tejang!",
    joinPass: 'Kidspace Pass sotib olish',
    currentPlan: 'Joriy Tarif',
    active: 'Faol',
    inactive: 'Faol emas',
    remainingBalance: 'Balans qoldig\'i',
    manageSubs: 'Boshqarish',
    linkedChildren: 'Abonementdagi bolalar',
    choosePackage: 'Paketingizni tanlang',
    visitsCount: 'tashrif',
    buyPackage: 'Paket Sotib Olish',
    healthTitle: 'Salomatlik',
    chatWithDoctor: 'Shifokor bilan chat',
    notificationSettings: 'Bildirishnoma Sozlamalari',
    myChats: 'Mening Chatlarim',
    sendMessage: 'Xabar yozish'
  }
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('ru');
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [selectedChild, setSelectedChild] = useState<Child | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [reviewTargetId, setReviewTargetId] = useState<string | null>(null);
  const [uiState, setUiState] = useState<UIState>({
    isChatOpen: false,
    activeModal: 'none',
    chatTriggerMsg: ''
  });
  
  const [bookingDraft, setBookingDraft] = useState<BookingDraft>({
    institution: null,
    service: null,
    date: null,
    time: null,
    child: null
  });

  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [chatSessions, setChatSessions] = useState<ChatSession[]>(MOCK_USERS[0].chats || []);
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  
  // Payment State
  const [paymentConfig, setPaymentConfig] = useState<PaymentConfig | null>(null);

  const t = (key: keyof typeof translations['ru']) => translations[language][key] || key;

  const openChat = (msg?: string) => {
    setUiState(prev => ({ ...prev, isChatOpen: true, chatTriggerMsg: msg || '' }));
  };

  const closeChat = () => {
    setUiState(prev => ({ ...prev, isChatOpen: false, chatTriggerMsg: '' }));
  };

  const toggleModal = (modal: UIState['activeModal']) => {
    setUiState(prev => ({
      ...prev,
      activeModal: prev.activeModal === modal ? 'none' : modal
    }));
  };

  const openDoctorConsultation = (doctor: Doctor) => {
    openChatWith('doctor', doctor);
  };

  const openChildProfile = (child: Child) => {
    setSelectedChild(child);
    setUiState(prev => ({ ...prev, activeModal: 'child_profile' }));
  };

  const openProductDetails = (product: Product) => {
    setSelectedProduct(product);
    setUiState(prev => ({ ...prev, activeModal: 'product_details' }));
  };

  const openReviewModal = (institutionId: string) => {
    setReviewTargetId(institutionId);
    setUiState(prev => ({ ...prev, activeModal: 'add_review' }));
  };

  const startBooking = (institution: Institution, service?: Service) => {
    setBookingDraft({
      institution,
      service: service || null,
      date: null,
      time: null,
      child: MOCK_USERS[0].children[0] || null
    });
    setUiState(prev => ({ ...prev, activeModal: 'booking_create' }));
  };

  const updateBookingDraft = (updates: Partial<BookingDraft>) => {
    setBookingDraft(prev => ({ ...prev, ...updates }));
  };

  const addToCart = (product: Product, quantity: number, options?: Record<string, string>) => {
    const optionStr = options ? JSON.stringify(options) : '';
    const itemId = `${product.id}-${optionStr}`;

    setCartItems(prev => {
      const existing = prev.find(item => item.id === itemId);
      if (existing) {
        return prev.map(item => item.id === itemId ? { ...item, quantity: item.quantity + quantity } : item);
      } else {
        return [...prev, {
          id: itemId,
          productId: product.id,
          productName: product.name,
          productImage: product.images[0],
          price: product.price,
          quantity,
          selectedOptions: options
        }];
      }
    });
  };

  const removeFromCart = (itemId: string) => {
    setCartItems(prev => prev.filter(item => item.id !== itemId));
  };

  const updateCartQuantity = (itemId: string, delta: number) => {
    setCartItems(prev => prev.map(item => {
      if (item.id === itemId) {
        const newQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const clearCart = () => {
    setCartItems([]);
  };

  const openChatList = () => {
    setUiState(prev => ({ ...prev, activeModal: 'chat_list' }));
  };

  const openChatWith = (type: 'support' | 'doctor' | 'institution', entity: any) => {
    let existingChat: ChatSession | undefined;
    
    if (type === 'support') {
      existingChat = chatSessions.find(c => c.type === 'support');
    } else if (entity) {
      existingChat = chatSessions.find(c => c.participantId === entity.id && c.type === type);
    }

    if (existingChat) {
      setActiveChatId(existingChat.id);
      setUiState(prev => ({ ...prev, activeModal: 'chat_room' }));
    } else {
      const newChat: ChatSession = {
        id: `chat_new_${Date.now()}`,
        type,
        participantId: type === 'support' ? 'support_1' : entity.id,
        participantName: type === 'support' ? 'KidSpace Support' : entity.name,
        participantAvatar: type === 'support' 
          ? 'https://img.icons8.com/fluency/96/customer-support.png' 
          : (type === 'institution' ? entity.images[0] : entity.image),
        participantRole: type === 'support' ? 'Служба поддержки' : (type === 'doctor' ? entity.specialty : 'Администратор'),
        isOnline: type === 'support' ? true : (type === 'doctor' ? entity.isOnline : false),
        unreadCount: 0,
        messages: [],
        lastMessage: '',
        lastMessageTime: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})
      };

      setChatSessions(prev => [newChat, ...prev]);
      setActiveChatId(newChat.id);
      setUiState(prev => ({ ...prev, activeModal: 'chat_room' }));
    }
  };

  const sendMessage = (chatId: string, text: string) => {
    const newMessage: ChatMessage = {
      id: `msg_${Date.now()}`,
      senderId: 'me',
      text,
      timestamp: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}),
      type: 'text',
      isRead: true
    };

    setChatSessions(prev => prev.map(chat => {
      if (chat.id === chatId) {
        return {
          ...chat,
          messages: [...chat.messages, newMessage],
          lastMessage: text,
          lastMessageTime: newMessage.timestamp
        };
      }
      return chat;
    }));

    setTimeout(() => {
      const replyMessage: ChatMessage = {
        id: `msg_r_${Date.now()}`,
        senderId: 'other',
        text: 'Спасибо за сообщение. Мы ответим вам в ближайшее время.',
        timestamp: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}),
        type: 'text',
        isRead: false
      };
      setChatSessions(prev => prev.map(chat => {
        if (chat.id === chatId) {
          return {
            ...chat,
            messages: [...chat.messages, replyMessage],
            lastMessage: replyMessage.text,
            lastMessageTime: replyMessage.timestamp,
            unreadCount: 0 
          };
        }
        return chat;
      }));
    }, 2000);
  };

  // --- PAYMENT LOGIC ---
  const openPayment = (config: PaymentConfig) => {
    setPaymentConfig(config);
    setUiState(prev => ({ ...prev, activeModal: 'payment' }));
  };

  const processPayment = async (method: 'wallet' | 'click' | 'payme' | 'uzum') => {
    return new Promise<{ success: boolean; message?: string }>((resolve) => {
      setTimeout(() => {
        if (method === 'wallet') {
          const balance = MOCK_USERS[0].walletBalance || 0;
          if (paymentConfig && balance >= paymentConfig.amount) {
            resolve({ success: true });
          } else {
            resolve({ success: false, message: 'Недостаточно средств на кошельке' });
          }
        } else {
          // Simulate external gateway success
          resolve({ success: true });
        }
      }, 2000); // Simulate network delay
    });
  };

  const closeAllModals = () => {
    setUiState(prev => ({ ...prev, activeModal: 'none', isChatOpen: false }));
  };

  return (
    <AppContext.Provider value={{
      language,
      setLanguage,
      t,
      uiState,
      selectedDoctor,
      selectedChild,
      selectedProduct,
      reviewTargetId,
      bookingDraft,
      cartItems,
      chatSessions,
      activeChatId,
      paymentConfig,
      openChat,
      closeChat,
      toggleModal,
      closeAllModals,
      openDoctorConsultation,
      openChildProfile,
      openProductDetails,
      openReviewModal,
      startBooking,
      updateBookingDraft,
      addToCart,
      removeFromCart,
      updateCartQuantity,
      clearCart,
      openChatList,
      openChatWith,
      sendMessage,
      openPayment,
      processPayment
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error("useAppContext must be used within an AppProvider");
  return context;
};